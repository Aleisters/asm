﻿using Asm1670.Data;
using Asm1670.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;

namespace AsmDotNet.Controllers
{
    public class BookController : Controller
    {
        private readonly ApplicationDbContext context;
        public BookController(ApplicationDbContext Dbcontext)
        {
            this.context = Dbcontext;
        }

        public IActionResult ViewBook()
        {
            var book = context.Book.ToList();
            return View(book);
        }
        public IActionResult Index()
        {
            var index = context.Book.ToList();
            return View(index);
        }
        
        public IActionResult Detail(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
                
            var book = context.Book
                .Include(e => e.Cart)
                .Include(e => e.Customer)
                .FirstOrDefault(m => m.Id == id);
            return View(book);
        }
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();

            }
            var book = context.Book.Find(id);
            context.Book.Remove(book);
            context.SaveChanges();

            return RedirectToAction(nameof(ViewBook));
        }
        public IActionResult AddCart()
        {
            
            return RedirectToAction(nameof(Index));
        }
        public IActionResult Create()
        {

            var cart = context.Cart.ToList();
            var customer = context.Customer.ToList();
            ViewBag.Cart = cart;
            ViewBag.Customer = customer;
            return View();
        }
        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (ModelState.IsValid)
            {
                context.Book.Add(book);
                context.SaveChanges();
                return RedirectToAction("ViewBook");

            }
            return View(book);
        }

        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            var book = context.Book.Find(id);
            if (book == null)
            {
                return NotFound();
            }
            var author = context.Cart.ToList();
            var customer = context.Customer.ToList();
            ViewBag.Author = author;
            ViewBag.Customer = customer;
            return View(book);
        }


        [HttpPost]
        public IActionResult Edit(Book book)
        {
            if (ModelState.IsValid)
            {
                context.Book.Update(book);
                context.SaveChanges();
                return RedirectToAction("ViewBook");
            }
            return View(book);
        }

    }
}
